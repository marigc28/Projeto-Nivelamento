const icone = document.querySelector(".icone");
const navMenu = document.querySelector(".nav-menu");

icone.addEventListener("click",()=> {
    icone.classList.toggle('active');
    navMenu.classList.toggle('active');
})